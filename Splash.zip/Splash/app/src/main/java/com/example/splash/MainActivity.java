package com.example.splash;

import static android.content.Intent.getIntent;
import static android.os.Build.VERSION_CODES.R;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        ghesmat ghereftan etla at ersal shode
        Intent reciveData=getIntent();
       String sName= reciveData.getStringExtra("name");
       String sFamily= reciveData.getStringExtra("Family");

        TextView txtNameAndFamily=findViewById(R.id.txtNameAndFamily);
        txtNameAndFamily.setText(sName+" - "+sFamily);

        SharedPreferences dbPref = getSharedPrefrences("myDb", Context.MODE_PRIVATE);



        String ssname=  dbPref.getString("name","no data");
        String ssfamily=  dbPref.getString("family","no data");
        txtNamayesh.setText(ssname+" - "+ssfamily);

    }
}