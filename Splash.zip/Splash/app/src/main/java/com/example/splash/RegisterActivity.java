package com.example.splash;

import static android.os.Build.VERSION_CODES.R;
import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;


public class RegisterActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);



        EditText editName =findViewById(R.id.editName);
        EditText editFamily =findViewById(R.id.editFamily);

        SharedPreferences dbPref = getSharedPrefrences("myDb", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = dbPref.edit();



        Button btnSubmit=findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                ghesmat zakhire etela at
                String sName=editName.getText().toString().trim();
                String sFamily=editFamily.getText().toString().trim();
                editor.putString("name",sName);
                editor.putString("family",sFamily);
                editor.apply();
                Toast.makeText(RegisterActivity.this,"اطلاعات با موفقیت ذخیره شد" ,Toast.LENGTH_SHORT).show();


//                ghesmat ersal etela at be aticity bade
                Intent intent =new Intent(RegisterActivity.this,MainActivity.class);
                intent.putExtra("name",sName);
                intent.putExtra("Family",sFamily);
                startActivity(intent);
            }
        });



        //        ghesmat ghereftan etela at zakhire shode
        TextView txtVakeshi = findViewById(R.id.txtVakeshi);
        Button btnVakeshi = findViewById(R.id.btnVakeshi);
        btnVakeshi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              String ssname=  dbPref.getString("name","no data");
              String ssfamily=  dbPref.getString("family","no data");
                txtVakeshi.setText(ssname+" - "+ssfamily);

            }
        });

        Button btnDel =findViewById(R.id.btnDel);
        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                editor.remove("name"); editor.remove("family");
                editor.clear();
                editor.apply();
                Toast.makeText(RegisterActivity.this,"اطلاعات با موفقیت حذف شد" ,Toast.LENGTH_SHORT).show();

            }
        });
    }
}